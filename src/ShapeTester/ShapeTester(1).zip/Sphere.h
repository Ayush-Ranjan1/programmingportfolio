#ifndef SPHERE_H
#define SPHERE_H

class Sphere
{
      private :
          int radius;
      public :
          Sphere(const int r = 0); 

          void setSphere(const int r);

          int calcSphereVol();

          int calcSphereSA();

          void print() const;
};

#endif
#include <iostream>
using namespace std;
#include "Box.h"
#include "Sphere.h"
#include "Pyramid.h"

int main() 
{
  int r,l,w,h,b,ph;
  cout << "What is the length of the box?: ";
  cin >> l;
  cout << "What is the width of the box?: ";
  cin >> w;
  cout << "What is the height of the box?: ";
  cin >> h;
  cout << "What is the radius of the sphere?: ";
  cin >> r;
  cout << "What is the width of the base of the pyramid?: ";
  cin >> b;
  cout << "What is the height of the pyramid?: ";
  cin >> ph;
  Box b1;
  b1.setBox(l, w, h);
  Sphere s1;
  s1.setSphere(r);
  Pyramid p1;
  p1.setPyramid(b,ph);
  cout << "Volume of the box: " << b1.calcVol();
  cout << "   Surface Area of the box: " << b1.calcSA() << endl;
  cout << "Volume of the Sphere: " << s1.calcSphereVol();
  cout << "   Surface Area of the Sphere: " << s1.calcSphereSA() << endl;
  cout << "Volume of the Pyramid: " << p1.calcPyramidVol();
  cout << "   Surface Area of the Pyramid: " << p1.calcPyramidSA() << endl;
  return 0;
}
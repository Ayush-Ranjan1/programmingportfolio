#include <iostream>
#include <iomanip>
#include "Box.h"
using namespace std;

Box :: Box(const int l, const int w, const int h)
{}

void Box :: setBox(const int l, const int w, const int h) 
{
  length = l;
  width = w;
  height = h;
}

int Box :: calcVol()
{
  int vol = length * width * height;
  return vol;
}

int Box :: calcSA()
{
  int sa = length * width * 2 + length * height * 2 + width * height * 2;
  return sa;
}

void Box :: print() const
{
  //cout << bla << endl;
}

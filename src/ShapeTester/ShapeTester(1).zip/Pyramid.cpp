#include <iostream>
#include <iomanip>
#include "Pyramid.h"
using namespace std;

Pyramid :: Pyramid(const int w, const int ph)
{}

void Pyramid :: setPyramid(const int w, const int ph) 
{
  width = w;
  height = ph;
}

int Pyramid :: calcPyramidVol()
{
  int vol = width * width * height /3;
  return vol;
}

int Pyramid :: calcPyramidSA()
{
  int sa = 1/2 * width * 4 * height + width * width;
  return sa;
}

void Pyramid :: print() const
{
  //cout << bla << endl;
}

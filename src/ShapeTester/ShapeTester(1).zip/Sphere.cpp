#include <iostream>
#include <iomanip>
#include "Sphere.h"
using namespace std;

Sphere :: Sphere(const int r)
{}

void Sphere :: setSphere(const int r) 
{
  radius = r;
}

int Sphere :: calcSphereVol()
{
  int spherevol = 4/3 * 3.14159 * radius * radius;
  return spherevol;
}

int Sphere :: calcSphereSA()
{
  int spheresa = 4 * 3.14159 * radius * radius;
  return spheresa;
}

void Sphere :: print() const
{
  //cout << bla << endl;
}

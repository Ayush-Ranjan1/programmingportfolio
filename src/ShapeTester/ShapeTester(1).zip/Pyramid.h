#ifndef PYRAMID_H
#define PYRAMID_H

class Pyramid
{
      private :
          int width;
          int height;
      public :
          Pyramid(const int w = 0, const int ph = 0); 

          void setPyramid(const int w, const int h);

          int calcPyramidVol();

          int calcPyramidSA();

          void print() const;
};

#endif
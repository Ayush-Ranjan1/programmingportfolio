#ifndef BOX_H
#define BOX_H

class Box
{
      private :
          int length;
          int width;
          int height;
      public :
          Box(const int l = 0, const int w = 0, const int h = 0); 

          void setBox(const int l, const int w, const int h);

          int calcVol();

          int calcSA();

          void print() const;
};

#endif
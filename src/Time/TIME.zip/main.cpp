#include <iostream>
#include <ctime>

using namespace std;



int main() {
  int day, month, year, currentday, currentmonth,currentyear, AgeMillennium, AgeCentury, AgeDecade, AgeYear, AgeMonth, AgeDay, AgeHour, AgeMinute, AgeSecond;
  string bday;
  string currentdate;

time_t now = time(0);
cout << "Enter your birthday: mm/dd/yyyy: ";
getline(cin, bday);

cout << "Enter the current date: mm/dd/yyyy: ";
getline(cin, currentdate);

day = stoi(bday.substr(3,4));
month = stoi(bday.substr(0,1));
year = stoi(bday.substr(6,9));
currentday = stoi(currentdate.substr(3,4));
currentmonth = stoi(currentdate.substr(0,1));
currentyear = stoi(currentdate.substr(6,9));
AgeYear = currentyear - year;
AgeMonth = AgeYear*12 - currentmonth;
AgeDay = AgeYear*365.25;
AgeMillennium = AgeYear/1000;
AgeCentury = AgeYear/100;
AgeDecade = AgeYear/10;
AgeHour = AgeDay*24;
AgeMinute = AgeHour*60;
AgeSecond = AgeMinute*60;
cout << "Age in Millennium: " << AgeMillennium << ", Age in Centuries: " << AgeCentury << ", Age in Decade: " << AgeDecade << ", Age in Years: " << AgeYear << ", Age in Months: " << AgeMonth << ", Age in Days: " << AgeDay << ", Age in Hours: " << AgeHour << ", Age in Minutes: " << AgeMinute << ", Age in Seconds: " << AgeSecond;
}